class PlayerException(Exception):
    """Global exception"""
